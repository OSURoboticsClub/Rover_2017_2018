This library is for use with the chdk cannon firmware.

it allows an arduino-like board to control zoom and shoot.

to enable this funcionality on the camera load firmware, enter <alt> mode, press menu, CHDK settings, Remote Parameters, enable remote, and set control mode to "zoom". 