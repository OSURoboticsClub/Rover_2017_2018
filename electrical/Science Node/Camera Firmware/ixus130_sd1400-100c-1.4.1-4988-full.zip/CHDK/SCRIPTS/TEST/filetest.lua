--[[
@title file browser test
@chdk_version 1.3
]]

f = file_browser("A/CHDK/SCRIPTS")

print(f)
